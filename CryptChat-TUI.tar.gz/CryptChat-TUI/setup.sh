#!/bin/bash

echo "[*] Inicjalizacja projektu CryptChat-TUI..."

# Sprawdzenie czy Python 3 jest zainstalowany
if ! command -v python3 &> /dev/null
then
    echo "[!] Python3 nie jest zainstalowany. Zainstaluj go i spróbuj ponownie."
    exit 1
fi

# Tworzenie struktury katalogów
mkdir -p client server docs

# Tworzenie pliku requirements.txt
cat << 'EOF' > requirements.txt
cryptography>=41.0.0
colorama>=0.4.6
EOF

echo "[*] Instalowanie zależności Pythona..."
pip install --upgrade pip
pip install -r requirements.txt

# Tworzenie przykładowego .env lub pliku konfiguracyjnego
cat << 'EOF' > config.json
{
  "default_host": "127.0.0.1",
  "default_port": 5000
}
EOF

echo "[+] Gotowe! Środowisko zostało pomyślnie skonfigurowane."
echo "[+] Uruchom serwer za pomocą: python3 server/server.py"
echo "[+] Uruchom klienta za pomocą: python3 client/client.py"
