import socket
import threading
import sys
from cryptography.fernet import Fernet
from colorama import init, Fore

init(autoreset=True)

# Dla uproszczenia w v1 używamy wspólnego klucza symetrycznego (wspólne "hasło" sesji)
# W v2 możemy dodać wymianę kluczy Diffie-Hellmana.
KEY = b'yRnIMOXtGOB7x7-pNAXq9QAdAlDQKAkCNmas2cqd1HA=' # Musi być dokładnie 32 bajty w base64 (Fernet wymaga 32url-safe base64-encoded bytes)
# Wygeneruj poprawny klucz za pomocą: Fernet.generate_key() i wpisz tutaj na stałe dla testów.

cipher = Fernet(KEY)

def receive_messages(sock):
    while True:
        try:
            encrypted_msg = sock.recv(4096)
            if not encrypted_msg:
                break
            decrypted_msg = cipher.decrypt(encrypted_msg).decode('utf-8')
            print(f"\n{Fore.GREEN}{decrypted_msg}{Fore.RESET}")
            sys.stdout.write("Ty: ")
            sys.stdout.flush()
        except Exception as e:
            print(f"\n{Fore.RED}[!] Utracono połączenie z serwerem.{Fore.RESET}")
            break

def start_client():
    host = input("Podaj adres IP serwera (domyślnie 127.0.0.1): ") or "127.0.0.1"
    port = int(input("Podaj port (domyślnie 5000): ") or 5000)

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client.connect((host, port))
    except:
        print(f"{Fore.RED}[!] Nie udało się połączyć z serwerem.{Fore.RESET}")
        return

    print(f"{Fore.CYAN}[+] Połączono z czatem! Szyfrowanie E2EE aktywne.{Fore.RESET}")

    thread = threading.Thread(target=receive_messages, args=(client,))
    thread.daemon = True
    thread.start()

    while True:
        msg = input("Ty: ")
        if msg.lower() == "/exit":
            break
        if msg.strip() == "":
            continue
        
        full_msg = f"Anon: {msg}"
        encrypted_msg = cipher.encrypt(full_msg.encode('utf-8'))
        client.send(encrypted_msg)

    client.close()

if __name__ == "__main__":
    start_client()
