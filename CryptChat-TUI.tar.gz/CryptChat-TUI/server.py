import socket
import threading

HOST = '0.0.0.0'
PORT = 5000

clients = []

def broadcast(message, sender_socket):
    for client in clients:
        if client != sender_socket:
            try:
                client.send(message)
            except:
                client.close()
                if client in clients:
                    clients.remove(client)

def handle_client(client_socket):
    while True:
        try:
            message = client_socket.recv(4096)
            if not message:
                break
            broadcast(message, client_socket)
        except:
            break

    if client_socket in clients:
        clients.remove(client_socket)
    client_socket.close()

def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen()
    print(f"[*] Serwer CryptChat wystartował na porcie {PORT}...")

    while True:
        client_socket, addr = server.accept()
        clients.append(client_socket)
        print(f"[+] Nowe połączenie z {addr}")
        thread = threading.Thread(target=handle_client, args=(client_socket,))
        thread.daemon = True
        thread.start()

if __name__ == "__main__":
    start_server()
